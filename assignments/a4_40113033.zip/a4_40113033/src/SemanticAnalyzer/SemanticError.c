/*
 * Ths file will contain functions that will be used for reporting semantic
 * errors.
 */

#include "SemanticError.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// This function prints a semantic error for us.

SemanticError create_error(const char *msg, err_code code, int line) {
  SemanticError err;
  err.code = code;
  err.line = line;

  char buffer[248]; // reserve buffer of 248 chars for the error message.
  if (code == err111) {
    snprintf(
        buffer, sizeof(buffer),
        "SEMANTIC ERROR LINE %d: Cannot lookup variable/function before it has "
        "been declared/defined, on line %d, %s used before declaration",
        line, line, msg);

    err.msg = strdup(buffer);
  } else if (code == err101) {
    snprintf(
        buffer, sizeof(buffer),
        "SEMANTIC ERROR ON LINE %d: Cannot implement functions for class that "
        "does not exist, class %s does not exist cannot implement .",
        line, msg);
    err.msg = strdup(buffer);
  } else if (code == err200) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot inherit a class that does not "
             "exist %s does not exist.",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err202) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot call function that has not "
             "been defined, function %s has not been defined ",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err203) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot implement a member function "
             "that has not been declared, function %s has not been declared.",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err204) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR on LINE %d: Cannot call function %s with "
             "different number of parameters exiting,",
             line, msg);
  } else if (code == err205) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot declare variable with type "
             "that does not exist, declaration of variable %s, with type that "
             "does not exist",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err206) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot have function parameters "
             "declared with type that does not exist, fparam %s onl line %d, "
             "declared with non-existent type.",
             line, msg, line);
    err.msg = strdup(buffer);
  } else if (code == err207) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Cannot have function that returns "
             "non-existent type, function %s on line %d, returns type that "
             "does not exist",
             line, msg, line);
    err.msg = strdup(buffer);
  } else if (code == err800) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Duplicate use of identifier %s in "
             "the same scope exiting",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err900) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERRROR ON LINE %d: Member function %s that has "
             "been declared but has not been defined.",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err701) {
    snprintf(
        buffer, sizeof(buffer),
        "SEMANTIC ERROR ON LINE %d: Cannot access a member from a non-class "
        "type or non-existent class type, %s is not a class type",
        line, msg);
    err.msg = strdup(buffer);
  } else if (code == err501) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Error on operator %s, cannot use %s "
             "on two different types",
             line, msg, msg);
    err.msg = strdup(buffer);

  } else if (code == err702) {
    snprintf(
        buffer, sizeof(buffer),
        "SEMANTIC ERROR ON LINE %d: No member called %s belongs to the class "
        "being accessed",
        line, msg);
    err.msg = strdup(buffer);
  } else if (code == err901) {
    snprintf(buffer, sizeof(buffer),
             "SEMANTIC ERROR ON LINE %d: Assignment cannot occur between a "
             "variable and an expression of another type, %s is not the "
             "expected type for the assignment.",
             line, msg);
    err.msg = strdup(buffer);
  } else if (code == err903) {
    snprintf(
        buffer, sizeof(buffer),
        "SEMANTIC ERROR ON LINE %d: Variable accessed with wrong number of "
        "dimensions, variable %s does not have that many array dimensions",
        line, msg);
    err.msg = strdup(buffer);
  }
  return err;
}
// Comparator function for qsort, this is to sort the errors based on their
// line numbers.
int compare_error_by_line(const void *err1, const void *err2) {

  const SemanticError *error1 = (const SemanticError *)err1;
  const SemanticError *error2 = (const SemanticError *)err2;

  return (error1->line - error2->line);
}

int insert_error(ErrorArray *arr, SemanticError err) {
  if (!arr) {
    fprintf(stderr, "ERROR - insert_error(): Could not allocate memory for the "
                    "erorr array exiting\n");
    return -1;
  }

  arr->errors =
      realloc(arr->errors, sizeof(SemanticError) * (arr->currentSize + 1));
  if (!arr) {
    fprintf(stderr, "ERROR - insert_error(): Could not allocate memory for the "
                    "new error entry, exiting\n");
    return -1;
  }

  arr->errors[arr->currentSize] = err;
  arr->currentSize += 1;

  return 1;
}

void sort_errors_by_line(ErrorArray *arr) {
  if (!arr) {
    fprintf(
        stderr,
        "ERROR - sort_errors_by_line(): Cannot sort, array not allocated.\n");
    return;
  }
  if (arr->errors == NULL) {
    // This just means that we have no errors in our array.
    return;
  }

  qsort(arr->errors, arr->currentSize, sizeof(SemanticError),
        compare_error_by_line);
}

ErrorArray *init_errors() {
  ErrorArray *arr = malloc(sizeof(ErrorArray));
  if (!arr) {
    fprintf(stderr, "ERROR - init_errors(): Cannot allocate memory for an "
                    "array of errors, exiting\n");
    return NULL;
  }

  arr->currentSize = 0;
  arr->errors = NULL;

  return arr;
}

// This will print an array of semantic errors, to an output stream.
void print_errors(FILE *out, ErrorArray *err) {
  if (!out) {
    fprintf(stderr, "ERROR - print_errors(): Cannot print errors output "
                    "stream is null.\n");
    return;
  }
  if (!err) {
    fprintf(stderr, "ERROR - print_errors(): Cannot print errors output "
                    "stream is null.\n");
    return;
  }

  sort_errors_by_line(err);
  for (int i = 0; i < err->currentSize; i++) {
    fprintf(out, "%s\n", err->errors[i].msg);
  }

  fprintf(out, "End of Semantic Errors total of %d errors found.\n",
          err->currentSize);
}
